package entities.enums;

public enum TipologiaRivenditore {

	DISTRIBUTORE_AUTOMATICO, 
	RIVENDITORE_AUTORIZZATO
}
