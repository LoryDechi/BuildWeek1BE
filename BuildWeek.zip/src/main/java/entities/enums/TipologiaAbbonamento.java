package entities.enums;

public enum TipologiaAbbonamento {

	SETTIMANALE,
	MENSILE
}
