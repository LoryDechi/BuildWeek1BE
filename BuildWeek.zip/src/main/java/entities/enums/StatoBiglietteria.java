package entities.enums;

public enum StatoBiglietteria {

	ATTIVO,
	FUORI_SERVIZIO
}
