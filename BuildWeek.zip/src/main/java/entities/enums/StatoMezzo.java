package entities.enums;

public enum StatoMezzo {

	SERVIZIO,
	MANUTENZIONE
}
